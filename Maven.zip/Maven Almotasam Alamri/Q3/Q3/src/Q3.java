public class Q3 {
    public static void main(String[] args) {

        String[] Cars = new String[]{"Volvo", "BMW", "Ford", "Toyota", "Mercedes"};
        System.out.println("Number of cars the customer could buy:-");
        System.out.println("---------------------------------------");
        System.out.println(Cars[0]);
        System.out.println(Cars[1]);
        System.out.println(Cars[2]);
        System.out.println(Cars[3]);
        System.out.println(Cars[4]);
        System.out.println("---------------------------------------");
    }
}