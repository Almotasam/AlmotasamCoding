import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int costPrice;
        int sellingPrice;
		
		System.out.println("***************************************");
        System.out.println("Cost price and selling price of an item");
        System.out.println("***************************************");

        System.out.print("Please Enter the cost price of the item: ");
        costPrice = scan.nextInt();

        System.out.println("--------------------------------------------");

        System.out.print("Please Enter the selling price of the item: ");
        sellingPrice = scan.nextInt();

        System.out.println("--------------------------------------------");

        if (sellingPrice > costPrice) {
            System.out.println("The seller has made profit");
            System.out.println("--------------------------------------------");
            System.out.println("The profit seller made = " + (sellingPrice - costPrice) + " OMR");

        } else if (costPrice > sellingPrice) {
            System.out.println("The seller has incurred loss");
            System.out.println("--------------------------------------------");
            System.out.println("The loss seller incurred = " + (costPrice - sellingPrice) + " OMR");
        }
    }
}