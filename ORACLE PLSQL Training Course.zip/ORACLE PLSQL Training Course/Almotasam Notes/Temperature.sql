DECLARE
 temperature_in_celsius NUMBER := '&TemperatureInCelsius';
 temperature_in_fahrenheit NUMBER := (temperature_in_celsius * (9/5)) + 32;
 
BEGIN
 DBMS_Output.Put_Line('Temperature in Fahrenheit ' || temperature_in_fahrenheit);
END;
/