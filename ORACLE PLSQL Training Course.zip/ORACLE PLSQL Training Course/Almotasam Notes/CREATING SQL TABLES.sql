CREATE TABLE Registration (
  AcNo    NUMBER      Primary key,
  FName   VARCHAR(15) NOT NULL,
  LName   VARCHAR(15) NOT NULL,
  DOB     DATE,
  RegDate DATE        DEFAULT sysdate,
  CivilId NUMBER      NOT NULL,
  Gender  CHAR(1)     check(gender in ('F','M')),
  GSM     NUMBER(8)   Unique Constraint GSM NOT NULL,
  OpenBal NUMBER      check(OpenBal > 49)
);

CREATE TABLE Deposits (
  DNo        NUMBER           Primary key,
  AcNo       NUMBER           NOT NULL,
  DDATE      DATE             DEFAULT sysdate,
  DAmount    NUMBER           NOT NULL,
  DLocation  Varchar(10)      NOT NULL,
  FOREIGN KEY (AcNo) REFERENCES Registration(AcNo)
);

CREATE TABLE Withdrawls (
  WNo        NUMBER           Primary key,
  AcNo       NUMBER           NOT NULL,
  WDATE      DATE             DEFAULT sysdate,
  WAmount    NUMBER           NOT NULL,
  DLocation  Varchar(10)      NOT NULL,
  FOREIGN KEY (AcNo) REFERENCES Registration(AcNo)
);

insert into registration values 
(1,'ahmed','al-hosni','12-jan-2000',default,12123212,'M',55887799,60);

grant insert,update, delete, select on registration to appdev;
grant insert,update, delete, select on withdrawls to appdev;
grant insert,update, delete, select on deposits to appdev;