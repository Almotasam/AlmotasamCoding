public class Customer {
    public int id;
    public String name;
    public int cash;
}
