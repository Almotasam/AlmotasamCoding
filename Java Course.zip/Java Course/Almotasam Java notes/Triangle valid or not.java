import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int firstAngel;
        int secondAngel;
        int thirdAngel;
		
		System.out.println("**************************");
        System.out.println("Triangle valid or not");
        System.out.println("**************************");

        System.out.print("Please Enter the first triangle angle in degrees: ");
        firstAngel = scan.nextInt();

        System.out.println("--------------------------------------------");

        System.out.print("Please Enter the second triangle angle in degrees: ");
        secondAngel = scan.nextInt();

        System.out.println("--------------------------------------------");

        System.out.print("Please Enter the third triangle angle in degrees: ");
        thirdAngel = scan.nextInt();

        System.out.println("--------------------------------------------");

        if (firstAngel + secondAngel + thirdAngel == 180) {

            System.out.println("The triangle is valid");
        } else {
            System.out.println("The triangle is not valid");
        }
    }
}