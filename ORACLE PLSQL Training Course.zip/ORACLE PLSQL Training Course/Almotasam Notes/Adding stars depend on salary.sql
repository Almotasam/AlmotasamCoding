DECLARE
 v_empno EMP2.employee_id%TYPE := 176;
 v_asteris EMP2.STARS%TYPE NULL;
 v_salary EMP2.salary%TYPE;
 
BEGIN
 SELECT NVL (ROUND(salary/1000),0) INTO v_salary
 FROM EMP2 WHERE employee_id = v_empno;
 FOR i IN 1..v_salary
  LOOP
    v_asteris := v_asteris || '*';
  END LOOP;
  
  UPDATE EMP2 SET stars = v_asteris where employee_id = v_empno;
  COMMIT;
END;
/