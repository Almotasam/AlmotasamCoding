import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class Q5 extends HttpServlet {

    public void service(HttpServletRequest req,HttpServletResponse res) {
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        String username = req.getParameter("username");
        int age = Integer.parseInt(req.getParameter("age"));
        String gender = req.getParameter("gender");

        System.out.println("Welcome " + username);
        System.out.println("Register Success ");
        System.out.println("Email " + email);
        System.out.println("Password " + password);
        System.out.println("Age " + age);
        System.out.println("Gender " + gender);

        try {
            PrintWriter pw=res.getWriter();
            pw.println("Welcome " + username);
            pw.println("Register Success ");
            pw.println("Email " + email);
            pw.println("Password " + password);
            pw.println("Age " + age);
            pw.println("Gender " + gender);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
