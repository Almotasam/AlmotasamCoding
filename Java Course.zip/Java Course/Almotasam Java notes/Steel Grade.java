import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int hardness;
        double carbonContent;
        int tensileStrength;

        System.out.println("**************************");
        System.out.println("Grade of the steel program");
        System.out.println("**************************");


        System.out.print("Please Enter the hardness of the steel: ");
        hardness = scan.nextInt();

        System.out.println("--------------------------------------------");

        System.out.print("Please Enter the carbon content of the steel: ");
        carbonContent = scan.nextDouble();

        System.out.println("--------------------------------------------");

        System.out.print("Please Enter the tensile strength of the steel: ");
        tensileStrength = scan.nextInt();

        System.out.println("--------------------------------------------");

        if ((hardness > 50) && (carbonContent < 0.7) && (tensileStrength > 5600)) {
            System.out.println("Steel Grade is: 10");

        } else if ((hardness > 50) && (carbonContent < 0.7) && (tensileStrength <= 5600)) {
            System.out.println("Steel Grade is: 9");

        } else if ((hardness <= 50) && (carbonContent < 0.7) && (tensileStrength > 5600)) {
            System.out.println("Steel Grade is: 8");

        } else if ((hardness > 50) && (carbonContent >= 0.7) && (tensileStrength > 5600)) {
            System.out.println("Steel Grade is: 7");

        } else if ((hardness > 50) || (carbonContent < 0.7) || (tensileStrength > 5600)) {
            System.out.println("Steel Grade is: 6");

        } else {
            System.out.println("Steel Grade is: 5");
        }
    }
}