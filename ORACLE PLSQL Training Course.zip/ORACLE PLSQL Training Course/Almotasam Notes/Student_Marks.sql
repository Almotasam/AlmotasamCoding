DECLARE
 s_name VARCHAR(50) := '&EnterName';
 s_eng NUMBER := '&EnglishMark';
 s_maths NUMBER := '&MathsMark';
 s_sicence NUMBER := '&SienceMark';
 
 s_total NUMBER := s_eng + s_maths + s_sicence;
 s_avg NUMBER := s_total/3;
 
BEGIN
 DBMS_Output.Put_Line(s_name || ' has got ' || s_total || ' Marks');
 DBMS_Output.Put_Line(s_name || ' has got ' || s_avg || ' Marks');
END;
/