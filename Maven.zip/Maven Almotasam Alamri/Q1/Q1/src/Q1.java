import java.util.Scanner;

public class Q1 {
    public static void main( String[] args ) {

        Scanner scan = new Scanner(System.in);

        boolean b;

        do {
            int x;
            int y;
            b = true;

            do {
                System.out.print("Please enter the first number: ");
                System.out.println("");
                while (!scan.hasNextInt()) {
                    String input = scan.next();
                    System.out.print(input + " is not a valid number. Please enter a valid number: ");
                    System.out.println("");
                }
                x = scan.nextInt();
            } while (x == 0);

            do {
                System.out.print("Please enter the second number: ");
                System.out.println("");
                while (!scan.hasNextInt()) {
                    String input = scan.next();
                    System.out.print(input + " is not a valid number. Please enter a valid number: ");
                    System.out.println("");
                }
                y = scan.nextInt();
            } while (y == 0);

            int sum = x + y;

            if ((sum > 100) && (x % 2 == 0) && (y % 2 == 0) && (x > 0) && (y > 0)) {
                System.out.println("**************");
                System.out.println("Mission Done");
                System.out.println("**************");
                b = false;
            }
        } while (b == true);
    }
}