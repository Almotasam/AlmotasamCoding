DECLARE
 v_department departments%ROWTYPE;
 
BEGIN
 SELECT * INTO v_department
 FROM departments where department_id = '&EnterDepID';
 DBMS_Output.Put_Line('Department ID: ' || v_department.department_id);
 DBMS_Output.Put_Line('Department name: ' || v_department.department_name);
 DBMS_Output.Put_Line('Manager ID: ' || v_department.manager_id);
 DBMS_Output.Put_Line('Location ID: ' || v_department.location_id);
END;
/