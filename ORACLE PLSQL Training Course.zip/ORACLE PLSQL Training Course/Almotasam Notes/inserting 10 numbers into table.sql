 BEGIN
  FOR v_results IN 1..10
   IF v_results = 6 OR v_results = 8 THEN
    NULL;
   ELSE
  LOOP
	INSERT INTO messages (results) 
	VALUES (v_results);
   END IF;
  END LOOP;
END;
/
