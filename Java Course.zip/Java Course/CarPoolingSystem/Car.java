package CarPoolingSystem;

import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;

public class Car {

    private long id;
    private String name;
    private String model;
    private int makeYear;
    private String company;
    private int comfortLevel;
    private static long count = 0;
    public static Set<Car> carSet = null;


    public Car(String name, String model, int makeYear, String company, int comfortLevel) {
        this.id = ++count;
        this.name = name;
        this.model = model;
        this.makeYear = makeYear;
        this.company = company;
        this.comfortLevel = comfortLevel;
    }

    public long getId() {
        return id;
    }

    @Override
    public String toString() {
        return ('\n' + "--------------------------------------------" + '\n' + "Car ID: " + id + '\n' + "Car name: " + name + '\n' + "Car model: " + model + '\n' + "Car make year: " + makeYear + '\n' + "Company: " + company + '\n'
                + "Car comfort level: " + comfortLevel);
    }

    public static void createCarSet (){
        Scanner scan = new Scanner(System.in);

        int carsWantedToAdd = 0;
        do {
            System.out.print("Please enter how many many cars you want to add: ");
            while (!scan.hasNextInt()) {
                String input = scan.next();
                System.out.print(input + " is not a valid number. Please enter how many many cars you want to add: ");
            }
            carsWantedToAdd = scan.nextInt();
        } while (carsWantedToAdd == 0);

        carSet = new LinkedHashSet<>();
        for(int i=1; i<=carsWantedToAdd; i++){
            carSet.add(addCar());
        }
    }

    public static Car addCar() {
        Scanner scan = new Scanner(System.in);
        String name;
        String model;
        int makeYear = 0;
        String company;
        int comfortLevel = 0;

        System.out.println("********************************************************");
        System.out.println("Please Enter the following information to add a car: ");
        System.out.println("********************************************************");

        System.out.print("Please Enter the car name: ");
        name = scan.next();
        System.out.println("--------------------------------------------");

        System.out.print("Please Enter the car model: ");
        model = scan.next();
        System.out.println("--------------------------------------------");

        do {
            System.out.print("Please Enter the year car made on: ");
            while (!scan.hasNextInt()) {
                String input = scan.next();
                System.out.print(input + " is not a valid year. Please Enter the year car made on: ");
            }
            makeYear = scan.nextInt();
        } while (makeYear == 0);
        System.out.println("--------------------------------------------");

        System.out.print("Please Enter the company which made the car: ");
        company = scan.next();
        System.out.println("--------------------------------------------");

        do {
            System.out.print("Please Enter the comfort level of the car: ");
            while (!scan.hasNextInt()) {
                String input = scan.next();
                System.out.print(input + " is not a valid number. Please Enter the comfort level of the car: ");
            }
            comfortLevel = scan.nextInt();
        } while (comfortLevel == 0);
        System.out.println("--------------------------------------------");

        Car car = new Car(name, model, makeYear, company, comfortLevel);
        return car;
    }

    public static Car findCar() {
        Scanner scan = new Scanner(System.in);
        int carId = 0;
        do {
            System.out.print("Please Enter car ID: ");
            while (!scan.hasNextInt()) {
                String input = scan.next();
                System.out.print(input + " is not a valid number. Please Enter car ID: ");
            }
            carId = scan.nextInt();
        } while (carId == 0);
        System.out.println("--------------------------------------------");
        Car c = null;
        for (Car car: carSet) {
            if (car.getId() == carId) {
                c = car;
            }
        }
        return c;
    }
}
