DECLARE
 v_deptid departments.department_id%TYPE;
 v_dname departments.department_name%TYPE;
 v_manid departments.manager_id%TYPE;
 v_locid departments.location_id%TYPE;
 
BEGIN
 SELECT department_id, department_name, manager_id, location_id 
 INTO v_deptid, v_dname, v_manid, v_locid
 FROM departments where department_id = '&EnterDepID';
 DBMS_Output.Put_Line('Department ID: ' || v_deptid);
 DBMS_Output.Put_Line('Department name: ' || v_dname);
 DBMS_Output.Put_Line('Manager ID: ' || v_manid);
 DBMS_Output.Put_Line('Location ID: ' || v_locid);
END;
/