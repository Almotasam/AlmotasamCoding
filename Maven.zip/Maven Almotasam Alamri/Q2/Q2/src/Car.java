public class Car {
    public int id;
    public String name;
    public int price;
}
