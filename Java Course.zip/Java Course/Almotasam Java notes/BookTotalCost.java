import java.util.Scanner;
public class Main {

    public static void main(String[] args) {

        Book book = new Book();

        System.out.println("*****************************************************");
        System.out.println("Total cost of books purchase program");
        System.out.println("*****************************************************");
        book.input();
        System.out.println("Total cost is: " + book.totalCost());
    }
}

import java.util.Scanner;
public class Book {

    private int bookNo;
    private String bookTitle;
    private float price;
    private int numberOfCopies;

    public float totalCost() {
        return price * numberOfCopies;
    }

    public void input(){
        Scanner scan = new Scanner(System.in);

        System.out.print("Please Enter the book number: ");
        bookNo = scan.nextInt();
        System.out.println("--------------------------------------------");

        System.out.print("Please Enter the book title: ");
        bookTitle = scan.next();
        System.out.println("--------------------------------------------");

        System.out.print("Please Enter the book price: ");
        price = scan.nextFloat();
        System.out.println("--------------------------------------------");

        System.out.print("Please Enter the number of copies you want to buy: ");
        numberOfCopies = scan.nextInt();
        System.out.println("--------------------------------------------");
    }
}
