import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int days;

        System.out.println("*****************************************************");
        System.out.println("Library Charging fine for returning book late program");
        System.out.println("*****************************************************");

        System.out.print("Please Enter the number of days the member is late to return the book: ");
        days = scan.nextInt();

        System.out.println("--------------------------------------------");

        if (days <= 5) {
            System.out.println("The charging fine is 50 Paise");

        } else if (days > 5 && days <= 10) {
            System.out.println("The charging fine is 1 Rupee");

        } else if (days > 10 && days <= 30) {
            System.out.println("The charging fine is 5 Rupee");

        } else {
            System.out.println("The membership will be cancelled");
        }
    }
}