import java.util.Scanner;

public class Q2 {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("");
        System.out.println("...Welcome Back...");
        System.out.println("------------------");
        System.out.println("Customer Data:-");
        System.out.println("");

        Customer customer = new Customer();
        Car car = new Car();

        do {
            System.out.print("Please Enter the customer ID: ");
            while (!scan.hasNextInt()) {
                String input = scan.next();
                System.out.print(input + " is not a valid number. Please Enter a valid number: ");
            }
            customer.id = scan.nextInt();
        } while (customer.id == 0);

        System.out.println("");
        System.out.print("Please Enter the customer name: ");
        customer.name = scan.next();

        do {
            System.out.println("");
            System.out.print("Please Enter how much customer has cash: ");
            while (!scan.hasNextInt()) {
                String input = scan.next();
                System.out.print(input + " is not a valid number. Please Enter a valid number: ");
                System.out.println("");
            }
            customer.cash = scan.nextInt();
        } while (customer.cash == 0);

        System.out.println("");
        System.out.println("------------------");
        System.out.println("Car Data:-");
        System.out.println("");

        do {
            System.out.print("Please Enter the car ID: ");
            while (!scan.hasNextInt()) {
                String input = scan.next();
                System.out.print(input + " is not a valid number. Please Enter a valid number: ");
            }
            car.id = scan.nextInt();
        } while (car.id == 0);

        System.out.println("");
        System.out.print("Please Enter the car name: ");
        car.name = scan.next();

        do {
            System.out.println("");
            System.out.print("Please Enter the car price: ");
            System.out.println("");
            while (!scan.hasNextInt()) {
                String input = scan.next();
                System.out.print(input + " is not a valid number. Please Enter a valid number: ");
                System.out.println("");
            }
            car.price = scan.nextInt();
        } while (car.price == 0);

        if (customer.cash >= car.price) {
            System.out.println("");
            System.out.print("Congratulations");
            System.out.println("");
        } else {
            System.out.print("Sorry, you Can't Buy This Car");
            System.out.println("");
        }
    }
}