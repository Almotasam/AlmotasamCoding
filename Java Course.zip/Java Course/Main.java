import CarPoolingSystem.Car;
import CarPoolingSystem.Member;
import CarPoolingSystem.MemberCar;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        int choice;



       do {

           System.out.println("");
           do {
               System.out.print("1. Show All Members" + '\n' + "2. Add Member" + '\n' + "3. Find Member" + '\n' + "4. Show All Cars" + '\n' + "5. Add Car" + '\n' + "6. Find Car" + '\n'
                       + "7. Cars Owned List" + '\n' + "8. Assign Car to member" + '\n' + "Please Choose one of the above options by inputting the number of that choice: ");
               while (!scan.hasNextInt()) {
                   String input = scan.next();
                   System.out.print(input + " is not a valid number" + '\n' + "1. Add Member" + '\n' + "2. Find Member" + '\n' + "3. Add Car" + '\n' + "4. Find Car" + '\n' + "Please Choose one of the above options by inputting the number of that choice: ");
               }
               choice = scan.nextInt();
           } while (choice == 0);
           System.out.println("--------------------------------------------");

            switch (choice) {

                case 1:
                    System.out.println("************");
                    System.out.println("Members List");
                    System.out.println("************");
                    System.out.println(Member.memberSet);
                    System.out.println("============================================");
                    break;
                case 2:
                    Member.createMemberSet();
                    System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
                    break;
                case 3:
                    Member.findMember();
                    System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
                    break;
                case 4:
                    System.out.println("*********");
                    System.out.println("Cars List");
                    System.out.println("*********");
                    System.out.println(Car.carSet);
                    System.out.println("============================================");
                case 5:
                    Car.createCarSet();
                    System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
                break;
                case 6:
                    Car.findCar();
                    System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
                break;
                case 7:
                    System.out.println("*********");
                    System.out.println("Cars Owned List");
                    System.out.println("*********");
                    System.out.println(MemberCar.carsOwnedSet);
                    System.out.println("============================================");
                break;
                case 8:
                    MemberCar.createCarOwnedSet();
                    System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
                    break;
            }

        } while (true);
    }
}