create table emp(empid number primary key, ename varchar(20), salary number);

insert into emp values (100, 'arif', 1000);

insert into emp values (101, 'al-azhar', 1100);

insert into emp values (102, 'almotasam', 1200);