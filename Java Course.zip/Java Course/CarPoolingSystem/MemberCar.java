package CarPoolingSystem;

import java.util.*;

public class MemberCar {

    long id;
    long memberId;
    long carId;
    String carRegistrationNumber;
    String carColor;
    private static long count = 0;
    public static Set<MemberCar> carsOwnedSet = null;

    public MemberCar(long memberId,  long carId, String carRegistrationNumber, String carColor) {
        this.id = ++count;
        this.memberId = memberId;
        this.carId = carId;
        this.carRegistrationNumber = carRegistrationNumber;
        this.carColor = carColor;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MemberCar memberCar = (MemberCar) o;
        return Objects.equals(carRegistrationNumber, memberCar.carRegistrationNumber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(carRegistrationNumber);
    }

    @Override
    public String toString() {
        return ('\n' + "--------------------------------------------" + '\n' + '\n' + "Assigning ID: " + id + "Member ID: " + memberId + '\n' + "Car ID: " + carId + '\n'
                + "Member car registration number: " + carRegistrationNumber + '\n' + "Car Color: " + carColor);
    }

    public static void createCarOwnedSet (){
        Scanner scan = new Scanner(System.in);

        int carsWantedToAssign = 0;
        do {
            System.out.print("Please enter how many cars you want to add: ");
            while (!scan.hasNextInt()) {
                String input = scan.next();
                System.out.print(input + " is not a valid number. Please enter how many cars you want to add: ");
            }
            carsWantedToAssign = scan.nextInt();
        } while (carsWantedToAssign == 0);

        carsOwnedSet = new LinkedHashSet<>();
        for(int i=1; i<=carsWantedToAssign; i++){
            if(carsOwnedSet.add(assignCar()) == true) {
                System.out.println("============================================");
                System.out.println("Car has been assigned successfully");
                System.out.println("============================================");
            }
            else {
                System.out.println("============================================");
                System.out.println("Car already assigned");
                System.out.println("============================================");
            }
        }
    }

    public static MemberCar assignCar() {
        Scanner scan = new Scanner(System.in);
        long memberId;
        long carId;
        String carRegistrationNumber;
        String carColor;

        System.out.println("********************************************************");
        System.out.println("Please Enter the following information to assign a car: ");
        System.out.println("********************************************************");

        System.out.print("Please Enter car owner member Id: ");
        memberId = scan.nextInt();
        System.out.println("--------------------------------------------");

        System.out.print("Please Enter the car ID you want to assign to above member: ");
        carId = scan.nextInt();
        System.out.println("--------------------------------------------");

        System.out.print("Please Enter the car registration number: ");
        carRegistrationNumber = scan.next();
        System.out.println("--------------------------------------------");

        System.out.print("Please Enter the Car color: ");
        carColor = scan.next();
        System.out.println("--------------------------------------------");

        MemberCar memberCar = new MemberCar(memberId, carId, carRegistrationNumber, carColor);
        return memberCar;
    }


}
