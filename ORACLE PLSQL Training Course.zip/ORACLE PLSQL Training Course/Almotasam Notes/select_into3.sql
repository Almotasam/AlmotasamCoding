DECLARE  
 bonus  NUMBER(8,2); -- 8 digits and 2 after point example(10.22)
 emp_id NUMBER(6) := 100; 
BEGIN 
 SELECT salary * 0.10 INTO bonus FROM employees     
 WHERE employee_id = emp_id; 
 Dbms_output.put_line(bonus);
END;