CREATE TYPE typ_item AS OBJECT (
  prodId NUMBER(5),
  price NUMBER(7,2))
/
CREATE TYPE typ_item_nst AS TABLE of typ_item
/
CREATE TABLE pOrder(
  ordId NUMBER(5),
  SUPPLIER NUMBER(5),
  REQESTER NUMBER(4),
  ordered DATE,
  items typ_item_nst)
  NESTED TABLE items STORE AS item_stor_tab
/

INSERT into pOrder values (500, 50, 5000, sysdate, typ_item_nst(
  typ_item(55, 555),
  typ_item(56, 56)));
