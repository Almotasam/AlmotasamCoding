package CarPoolingSystem;

import java.time.LocalDate;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Scanner;
import java.util.Set;

public class Member {

    private long id;
    private String firstName;
    private String lastName;
    private String email;
    private String contactNumber;
    private long licenseNumber;
    private LocalDate licenseStartDate;
    private LocalDate licenseExpiryDate;
    private static long count = 0;
    private static long count2 = 0;

    public static Set<Member> memberSet = null;

    public Member (String firstName, String lastName, String email, String contactNumber, LocalDate licenseStartDate, LocalDate licenseExpiryDate) {
        this.id = ++count;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.contactNumber = contactNumber;
        this.licenseNumber = ++count2;
        this.licenseStartDate = licenseStartDate;
        this.licenseExpiryDate = licenseExpiryDate;
    }

    public long getId() {
        return id;
    }

    @Override
    public String toString() {
        return  ('\n' + "--------------------------------------------" + '\n' + "Member ID: " + id + '\n' + "Member first name: " + firstName + '\n' + "Member last name: " + lastName + '\n' + "Member email: " + email + '\n' + "contactNumber: " + contactNumber + '\n'
                + "Member License Number: " + licenseNumber + '\n' + "Member License Start Date: " + licenseStartDate + '\n' + "Member License Expiry Date: " + licenseExpiryDate);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Member member = (Member) o;
        return Objects.equals(email, member.email) && Objects.equals(contactNumber, member.contactNumber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(email, contactNumber);
    }

    public static void createMemberSet (){
        Scanner scan = new Scanner(System.in);

        int membersWantedToAdd = 0;
        do {
            System.out.print("Please enter how many members you want to add: ");
            while (!scan.hasNextInt()) {
                String input = scan.next();
                System.out.print(input + " is not a valid number. Please enter how many members you want to add: ");
            }
            membersWantedToAdd = scan.nextInt();
        } while (membersWantedToAdd == 0);

        memberSet = new LinkedHashSet<>();
        for(int i=1; i<=membersWantedToAdd; i++){
            if(memberSet.add(addMember()) == true) {
                System.out.println("============================================");
                System.out.println("Member has been added successfully");
                System.out.println("============================================");
            }
            else {
                System.out.println("============================================");
                System.out.println("Member already exist");
                System.out.println("============================================");
            }
        }
    }

    public static Member addMember() {
        Scanner scan = new Scanner(System.in);
        String firstName;
        String lastName;
        String email;
        String contactNumber;

        System.out.println("********************************************************");
        System.out.println("Please Enter the following information to add a member: ");
        System.out.println("********************************************************");

        System.out.print("Please Enter the first name: ");
        firstName = scan.next();
        System.out.println("--------------------------------------------");

        System.out.print("Please Enter the last name: ");
        lastName = scan.next();
        System.out.println("--------------------------------------------");

        System.out.print("Please Enter the Email: ");
        email = scan.next();
        System.out.println("--------------------------------------------");

        System.out.print("Please Enter the Phone Number: ");
        contactNumber = scan.next();
        System.out.println("--------------------------------------------");

        Member member = new Member(firstName, lastName, email, contactNumber, LocalDate.now(), LocalDate.now().plusYears(3));
        return member;
    }

    public static Member findMember() {
        Scanner scan = new Scanner(System.in);
        int memberId = 0;
        do {
            System.out.print("Please Enter member ID: ");
            while (!scan.hasNextInt()) {
                String input = scan.next();
                System.out.print(input + " is not a valid number. Please Enter member ID: ");
            }
            memberId = scan.nextInt();
        } while (memberId == 0);
        System.out.println("--------------------------------------------");
        Member m = null;
        for (Member member: memberSet) {
            if (member.getId() == memberId) {
                m = member;
            }
        }
        return m;
    }
}
