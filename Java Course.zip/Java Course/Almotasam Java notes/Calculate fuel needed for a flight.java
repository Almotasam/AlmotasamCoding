import java.util.Scanner;
public class Main {

    public static void main(String[] args) {

        Airline airline = new Airline();

        System.out.println("*****************************************************");
        System.out.println("Calculate fuel needed for a flight program");
        System.out.println("*****************************************************");
        airline.feedInfo();
        airline.showInfo();
    }
}

import java.util.Scanner;

public class Airline {

    int flightNo;
    String destination;
    float distance;
    float fuel;

    public float calFuel() {
        if (distance <= 1000) {
            fuel =  500;
        }

        if (1000 < distance && distance <= 2000) {
            fuel = 1100;
        }

        if (distance > 2000) {
            fuel = 2200;
        }

        return fuel;
    }

    public void feedInfo() {
        Scanner scan = new Scanner(System.in);

        System.out.print("Please Enter the flight number: ");
        flightNo = scan.nextInt();
        System.out.println("--------------------------------------------");

        System.out.print("Please Enter your destination: ");
        destination = scan.next();
        System.out.println("--------------------------------------------");

        System.out.print("Please Enter the distance: ");
        distance = scan.nextFloat();
        System.out.println("--------------------------------------------");
    }

    public void showInfo() {
        System.out.println("Flight Number: " + flightNo);
        System.out.println("Destination: " + destination);
        System.out.println("Distance: " + distance);
        System.out.println("The fuel needed to reach your destination: " + calFuel());
        System.out.println("--------------------------------------------");
    }
}
