import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int stock;
        int order;
        char credit;

        System.out.println("*****************************************************");
        System.out.println("Policy followed by a company program");
        System.out.println("*****************************************************");

        System.out.print("Please Enter the quantity of product in stock: ");
        stock = scan.nextInt();
        System.out.println("--------------------------------------------");

        System.out.print("Please Enter the quantity of the order: ");
        order = scan.nextInt();
        System.out.println("--------------------------------------------");

        System.out.print("Is his credit is ok (Type y/n): ");
        String str = scan.next();
        credit = str.charAt(0);
        System.out.println("--------------------------------------------");

        if (order <= stock && (credit == 'y' || credit == 'Y')) {
            System.out.print("Sir, We supplied your requirement Quantity: " + order);

        } else if (order>stock && (credit == 'y' || credit == 'Y')) {
            System.out.println("Sir, We supplied " + stock + " products and balance will be shipped later");

        } else {
            System.out.println("Sir, Please first clear your credit, until that we can't supply you any more");
        }
    }
}