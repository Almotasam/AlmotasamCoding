DECLARE
 v_name  VARCHAR2(20);

BEGIN
 v_name := 'Almotasam';
 DBMS_Output.Put_Line('hello:  ' || v_name);
END;
/