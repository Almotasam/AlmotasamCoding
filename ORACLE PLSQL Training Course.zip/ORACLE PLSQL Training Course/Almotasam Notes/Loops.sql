DECLARE
  n_counter NUMBER := 1;
BEGIN
  WHILE n_counter <= 10 
  LOOP
    DBMS_OUTPUT.PUT_LINE(n_counter);
    n_counter := n_counter + 1;
  END LOOP;
END;
/

DECLARE
  n_counter NUMBER := 1;
LOOP 
 DBMS_OUTPUT.PUT_LINE(n_counter);
 n_counter := n_counter + 1;;
EXIT [WHEN n_counter <= 10];
END LOOP;
/

BEGIN
  FOR l_counter IN 1..10
  LOOP
    DBMS_OUTPUT.PUT_LINE( l_counter );
  END LOOP;
END;
/
