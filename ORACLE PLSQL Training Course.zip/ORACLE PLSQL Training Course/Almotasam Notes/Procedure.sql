CREATE OR REPLACE PROCEDURE Reg_Add_Record(
  v_AcNo Registration.AcNo%TYPE,
  v_FName Registration.FName%TYPE,
  v_LName Registration.LName%TYPE,
  v_DOB Registration.DOB%TYPE,
  v_CivilId Registration.CivilId%TYPE,
  v_Gender Registration.Gender%TYPE,
  v_GSM Registration.GSM%TYPE,
  v_OpenBal Registration.OpenBal%TYPE) 
IS
BEGIN
  INSERT INTO Registration (AcNo, FName, LName, DOB, CivilId, Gender, GSM, OpenBal)
   VALUES (v_AcNo, v_FName, v_LName, v_DOB, v_CivilId, v_Gender, v_GSM, v_OpenBal);
END;
/
EXECUTE Reg_Add_Record

VALUES (2121, 'Almotasam', 'Alamri', sysdate, 10924749, 'M', 99586409, 50);