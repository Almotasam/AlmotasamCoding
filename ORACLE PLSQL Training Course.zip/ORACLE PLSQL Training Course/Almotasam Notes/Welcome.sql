BEGIN
 DBMS_Output.Put_Line('Welcome to Oracle PL/SQL Training Course');
END;
/