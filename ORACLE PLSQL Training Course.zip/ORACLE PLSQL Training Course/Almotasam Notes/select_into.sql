DECLARE
 v_empid NUMBER;
 v_ename VARCHAR(20);
 v_sal NUMBER;
 
BEGIN
 SELECT empid, ename, salary INTO v_empid, v_ename, v_sal
 FROM EMP where empid = 100;
 DBMS_Output.Put_Line('Employee ID: ' || v_empid);
 DBMS_Output.Put_Line('Employee name: ' || v_ename);
 DBMS_Output.Put_Line('Employee salary: ' || v_sal);
END;
/