import java.util.Scanner;
public class Main {

    public static void main(String[] args) {

        BatAvg batAvg = new BatAvg();

        System.out.println("*****************************************************");
        System.out.println("Calculate BatAvg program");
        System.out.println("*****************************************************");
        System.out.println("");
        batAvg.readData();
        batAvg.displayedData();
    }
}

import java.util.Scanner;

public class BatAvg {

    private int bCode;
    private String bName;
    private float innings;
    private float notOut;
    private float runs;
    private float batAvg;

    public float calcAvg() {
        batAvg = runs/(innings - notOut);
        return batAvg;
    }

    public void readData() {
        Scanner scan = new Scanner(System.in);

        System.out.print("Please Enter your bName: ");
        bName = scan.nextLine();
        System.out.println("--------------------------------------------");

        System.out.print("Please Enter the bCode: ");
        bCode = scan.nextInt();
        System.out.println("--------------------------------------------");

        System.out.print("Please Enter the innings: ");
        innings = scan.nextInt();
        System.out.println("--------------------------------------------");

        System.out.print("Please Enter the notOut: ");
        notOut = scan.nextInt();
        System.out.println("--------------------------------------------");

        if (innings == notOut) {
            System.out.println("innings and notOut can not be the same, Please type a valid innings and notOut");

            System.out.print("Please Enter the innings: ");
            innings = scan.nextInt();
            System.out.println("--------------------------------------------");

            System.out.print("Please Enter the notOut: ");
            notOut = scan.nextInt();
            System.out.println("--------------------------------------------");
        }

        if (notOut > innings) {
            System.out.println("notOut can not be bigger than innings, Please type a valid innings and notOut");

            System.out.print("Please Enter the innings: ");
            innings = scan.nextInt();
            System.out.println("--------------------------------------------");

            System.out.print("Please Enter the notOut: ");
            notOut = scan.nextInt();
            System.out.println("--------------------------------------------");
        }

        System.out.print("Please Enter how many runs: ");
        runs = scan.nextInt();
        System.out.println("--------------------------------------------");
    }

    public void displayedData() {
        System.out.println("bCode: " + bCode);
        System.out.println("bName: " + bName);
        System.out.println("innings: " + innings);
        System.out.println("notOut: " + notOut);
        System.out.println("runs: " + runs);
        System.out.println("BatAvg: " + calcAvg());
        System.out.println("--------------------------------------------");
    }
}